package edu.escuela.gamepz.utils;

public interface Muerto {
    public int MAX_ZOMBIES = 10;
    public void come();
}
